function startResearch() {
  const status = document.getElementById("status");
  status.innerText = "Researching Quranic and Scientific knowledge...";
  drawGraph();
}
function drawGraph() {
  const ctx = document.getElementById("graph").getContext("2d");
  ctx.clearRect(0, 0, 300, 300);
  ctx.beginPath();
  ctx.arc(150, 150, 100, 0, 2 * Math.PI);
  ctx.fillStyle = "#cfe2ff";
  ctx.fill();
  ctx.stroke();
}
