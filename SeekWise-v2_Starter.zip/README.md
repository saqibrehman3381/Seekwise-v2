# SeekWise v2
AI-Powered Quran-to-Science Auto-Research Engine.

## Features
- Auto Quranic Research
- Multilingual Support
- AI Insight Graphs
- Downloadable Reports
